---
id: scene_backstory_select
type: vn_scene
phase: sandbox_intro
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_ka
  - phase/entry
---

# 📜 Detective's Past

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_office_bg]] |
| 📖 Beat 1 | [[scene_backstory_dialogue]] |

## 🔀 Choices (Sets Initial Flags)
1. **The Veteran** (High Logic, Low Empathy) → `set_flag('BG_VETERAN')`
2. **The Aristocrat** (High Authority, High Money) → `set_flag('BG_ARISTOCRAT')`
3. **The Scholar** (High Occultism, Low Physique) → `set_flag('BG_SCHOLAR')`

## → Next
[[scene_map_intro]]
