---
id: scene_language_select
type: vn_scene
phase: sandbox_intro
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_ka
  - phase/entry
---

# 🌍 Language & Setup

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_office_bg]] |
| 📖 Beat 1 | [[scene_language_config]] |

## ⚙️ Config
- Select Language (DE/EN/RU)
- Set Text Speed
- Audio Calibration

## → Next
[[scene_backstory_select]]
