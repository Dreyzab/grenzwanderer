---
id: scene_map_intro
type: vn_scene
phase: sandbox_intro
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_ka
  - phase/entry
---

# 🗺️ Welcome to Karlsruhe

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_map_overview_bg]] |
| 📖 Beat 1 | [[scene_map_intro_beat1]] |

## Mechanics
- Unlocks Map Interface
- Unlocks Partner Icon
- Unlocks 3 Case Hubs

## → Exit
[[map_karlsruhe_main]]
