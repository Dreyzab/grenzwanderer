---
id: scene_start
type: vn_scene
phase: sandbox_intro
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_ka
  - phase/entry
---

# 🛫 Flight to Karlsruhe

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_start_bg]] |
| 📖 Beat 1 | [[scene_start_beat1]] |

## → Next
[[scene_language_select]]
