---
id: char_partner
type: mechanic
role: guide
tags:
  - type/mechanic
  - layer/map
  - case/sandbox_ka
---

# 🗣️ Partner Mechanic

## 📍 UI Representation
- **Icon**: Character Portrait in bottom-right corner of Map.
- **Badge**: Shows number of active hints/updates.

## 💬 Dialogue logic
**Condition**: `intro_completed` AND `cases_solved == 0`
> "We have 3 clients waiting. The Banker, the Mayor, and that spooky Estate. Pick anyone, I'll follow."

**Condition**: `banker_started`
> "The Banker's son is trouble. We should check the Tavern."

**Condition**: `dog_started`
> "A missing dog? Really? Well, let's ask the Butcher."

## → Purpose
Provides context-sensitive hints and reminders of current objectives without cluttering the quest log.
