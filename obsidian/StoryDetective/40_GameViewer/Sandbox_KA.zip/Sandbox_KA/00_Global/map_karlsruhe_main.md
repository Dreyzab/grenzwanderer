﻿---
id: map_karlsruhe_main
type: map_root
phase: sandbox_hub
status: active
tags:
  - type/map_root
  - layer/map
  - case/sandbox_ka
  - location/karlsruhe
---

# Map: Karlsruhe Main

## Hub Points
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_bank|Bank (The Banker's Son)]]
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_rathaus|Rathaus (The Mayor's Dog)]]
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_estate|Estate (The Haunted Manor)]]
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_agency|Detective Agency (Home)]]

## Service Points
- Marketplace (trade service, design-only node in this cycle).

## Mechanics
- [[40_GameViewer/Sandbox_KA/00_Global/char_partner|char_partner]] icon provides context hints.

## Transitions
- Any unlocked hub.
- Return targets from quest exits.
