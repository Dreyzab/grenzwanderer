﻿---
id: hub_agency
type: map_hub
location: loc_ka_agency
tags:
  - type/hub
  - function/home
  - case/sandbox_ka
---

# Detective Agency Hub

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Preconditions
- `intro_completed` is `true`.

## Designer View
Home base for recovery, dossier review, and loadout prep.

## Available Interactions
- Rest: restore hp and willpower.
- Archive: review solved cases and lore.
- Equipment: adjust active loadout.

## Available Quests
- Meet the Guildmaster (`guild_meeting`).
  - Requirement: `guildmaster_unlocked` is `true`.

## Mechanics View
- This hub is always available after map unlock.
- Guildmaster interaction becomes available after Ghost completion.

## State Delta
- No mandatory state mutation on enter.
- Rest and equipment actions mutate player resources/loadout.

## Transitions
- [[40_GameViewer/Sandbox_KA/01_Hubs/scene_agency_guildmaster|scene_agency_guildmaster]] when unlocked.
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Validation
- Guildmaster transition is hidden while `guildmaster_unlocked` is `false`.
- Return to map is always available.
