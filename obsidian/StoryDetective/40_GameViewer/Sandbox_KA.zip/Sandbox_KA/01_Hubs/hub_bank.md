﻿---
id: hub_bank
type: map_hub
location: loc_ka_bank
tags:
  - type/hub
  - function/quest_giver
  - case/sandbox_banker
---

# Karlsruhe Bank Hub

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Preconditions
- `intro_completed` is `true`.
- `banker_resolved` is `false`.

## Designer View
Entry point for the "Banker's Son" questline.

## Available Interactions
- Talk to the banker.
- Review current banker objective.

## Available Quests
- The Banker's Plea (`sandbox_banker`).
  - Reward: 50 XP, 100 Marks.

## Mechanics View
- Selecting quest start routes to the Banker quest entry wrapper.
- Hub availability is controlled by the preconditions above.

## State Delta
- No mandatory state mutation on hub open.
- Quest start state is applied in `scene_banker_entry`.

## Transitions
- [[40_GameViewer/Sandbox_KA/02_Quest_Entries/scene_banker_entry|scene_banker_entry]].
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Validation
- Hub is hidden or locked when `banker_resolved` is `true`.
- Hub is inaccessible before intro completion.
