﻿---
id: hub_estate
type: map_hub
location: loc_ka_estate
tags:
  - type/hub
  - function/quest_giver
  - case/sandbox_ghost
---

# Estate Hub

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Preconditions
- `intro_completed` is `true`.
- `ghost_resolved` is `false`.

## Designer View
Entry point for the "Haunted Estate" questline.

## Available Interactions
- Speak with estate contact.
- Review evidence objective.

## Available Quests
- The Ghost of Von Dorn (`sandbox_ghost`).
  - Reward: 80 XP, occult training.

## Mechanics View
- Selecting quest start routes to the Ghost quest entry wrapper.
- Hub availability is controlled by preconditions.

## State Delta
- No mandatory state mutation on hub open.
- Quest start state is applied in `scene_ghost_entry`.

## Transitions
- [[40_GameViewer/Sandbox_KA/02_Quest_Entries/scene_ghost_entry|scene_ghost_entry]].
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Validation
- Hub is hidden or locked when `ghost_resolved` is `true`.
- Hub is inaccessible before intro completion.
