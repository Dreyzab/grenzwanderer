﻿---
id: hub_rathaus
type: map_hub
location: loc_ka_rathaus
tags:
  - type/hub
  - function/quest_giver
  - case/sandbox_dog
---

# Rathaus Hub

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Preconditions
- `intro_completed` is `true`.
- `dog_resolved` is `false`.

## Designer View
Entry point for the "Mayor's Dog" questline.

## Available Interactions
- Talk to city officials.
- Check current breadcrumb progress.

## Available Quests
- Mayor's Best Friend (`sandbox_dog`).
  - Reward: 40 XP, reputation gain.

## Mechanics View
- Selecting quest start routes to the Dog quest entry wrapper.
- Hub availability is controlled by preconditions.

## State Delta
- No mandatory state mutation on hub open.
- Quest start state is applied in `scene_dog_entry`.

## Transitions
- [[40_GameViewer/Sandbox_KA/02_Quest_Entries/scene_dog_entry|scene_dog_entry]].
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Validation
- Hub is hidden or locked when `dog_resolved` is `true`.
- Hub is inaccessible before intro completion.
