---
id: scene_agency_guildmaster
type: vn_scene
phase: sandbox_ghost
tags:
  - type/interaction
  - character/guildmaster
---

# 🏛️ The Guildmaster's Evaluation

## 🔗 Linkage
From: [[hub_agency]]
To: [[map_karlsruhe_main]]

## 🎭 Context
**Background**: The Agency office, now occupied by an imposing figure.
**Guildmaster Klaus**: "You handled the Von Dorn haunting. Interesting methods."

## ⚙️ Mechanics
- **Evaluation**: Reviews your choices in the Ghost case (True vs False trail).
- **Reward**: Unlocks "Mind Palace" mechanics fully.
- **Progression**: Sets `sandbox_step = 'epilogue_ready'`.

## → Next
[[map_karlsruhe_main]]
