﻿---
id: scene_banker_entry
type: vn_scene
phase: sandbox_banker
tags:
  - type/connector
  - direction/entry
---

# Quest Entry: Banker

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/01_Hubs/hub_bank|hub_bank]].

## Preconditions
- `intro_completed` is `true`.
- `banker_resolved` is `false`.

## Designer View
- Background: polished marble lobby of the bank.
- Initial text: clerk escorts the player to Herr Wagner.
- First tone: urgent, confidential client request.

## Mechanics View
- Passive checks: perception and empathy flavor lines before first decision.
- Entry wrapper hands control to existing Banker plot chain.

## State Delta
- `set_quest_state('sandbox_banker', 'started')`

## Transitions
- [[40_GameViewer/Sandbox_KA/Plot/01_Banker/scene_bank_intro|scene_bank_intro]] (continue quest).
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]] (cancel and return).

## Validation
- Quest state must be `started` before leaving wrapper.
- Returning to map must not auto-complete quest.
