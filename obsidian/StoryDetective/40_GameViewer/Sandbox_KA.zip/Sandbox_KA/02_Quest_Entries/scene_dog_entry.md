﻿---
id: scene_dog_entry
type: vn_scene
phase: sandbox_dog
tags:
  - type/connector
  - direction/entry
---

# Quest Entry: Mayor's Dog

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/01_Hubs/hub_rathaus|hub_rathaus]].

## Preconditions
- `intro_completed` is `true`.
- `dog_resolved` is `false`.

## Designer View
- Background: mayor office in active disorder.
- Initial text: mayor paces with empty leash and requests help.
- First tone: comedic urgency with public pressure.

## Mechanics View
- Passive checks: composure and perception flavor before lead selection.
- Entry wrapper routes into Dog briefing chain.

## State Delta
- `set_quest_state('sandbox_dog', 'started')`

## Transitions
- [[40_GameViewer/Sandbox_KA/Plot/02_Dog/scene_dog_briefing|scene_dog_briefing]] (continue quest).
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]] (cancel and return).

## Validation
- Quest state must be `started` before leaving wrapper.
- Wrapper target must stay aligned with canvas routing.
