﻿---
id: scene_ghost_entry
type: vn_scene
phase: sandbox_ghost
tags:
  - type/connector
  - direction/entry
---

# Quest Entry: Ghost

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/01_Hubs/hub_estate|hub_estate]].

## Preconditions
- `intro_completed` is `true`.
- `ghost_resolved` is `false`.

## Designer View
- Background: overgrown estate gate in heavy fog.
- Initial text: servant contact waits and requests immediate help.
- First tone: mystery and unease.

## Mechanics View
- Passive checks: occultism and perception flavor lines.
- Entry wrapper hands control to existing Ghost plot chain.

## State Delta
- `set_quest_state('sandbox_ghost', 'started')`

## Transitions
- [[40_GameViewer/Sandbox_KA/Plot/03_Ghost/scene_estate_intro|scene_estate_intro]] (continue quest).
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]] (cancel and return).

## Validation
- Quest state must be `started` before leaving wrapper.
- Wrapper must not skip evidence and tutorial steps.
