﻿---
id: scene_banker_exit_to_map
type: vn_scene
phase: sandbox_banker
tags:
  - type/connector
  - direction/exit
---

# Return: Banker Case Complete

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/Plot/01_Banker/scene_casino_duel|scene_casino_duel]].

## Preconditions
- Duel outcome is successful.
- `sandbox_banker` can transition from `started` to `completed`.

## Designer View
- Debrief: Friedrich agrees to return home and the banker settles payment.

## Mechanics View
- Reward grant: +50 XP and +100 Marks.
- Case status update: banker branch marked complete.

## State Delta
- `set_quest_state('sandbox_banker', 'completed')`
- `banker_resolved = true`

## Transitions
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Validation
- Hub lock condition should activate for banker hub.
- Return path to map must always remain available.
