﻿---
id: scene_dog_exit_to_map
type: vn_scene
phase: sandbox_dog
tags:
  - type/connector
  - direction/exit
---

# Return: Dog Case Complete

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/Plot/02_Dog/scene_park_reunion|scene_park_reunion]].

## Preconditions
- Reunion outcome is successful.
- `sandbox_dog` can transition from `started` to `completed`.

## Designer View
- Debrief: Bruno is safe and the mayor is relieved.

## Mechanics View
- Reward grant: +40 XP and reputation increase.
- Case status update: dog branch marked complete.

## State Delta
- `set_quest_state('sandbox_dog', 'completed')`
- `dog_resolved = true`

## Transitions
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Validation
- Hub lock condition should activate for rathaus hub.
- Return path to map must always remain available.
