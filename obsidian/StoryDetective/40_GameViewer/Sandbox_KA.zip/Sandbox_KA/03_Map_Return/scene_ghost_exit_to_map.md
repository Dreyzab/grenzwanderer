﻿---
id: scene_ghost_exit_to_map
type: vn_scene
phase: sandbox_ghost
tags:
  - type/connector
  - direction/exit
---

# Return: Ghost Case Complete

## Trigger Source
- Entered from [[40_GameViewer/Sandbox_KA/Plot/03_Ghost/scene_conclusion_true|scene_conclusion_true]] or [[40_GameViewer/Sandbox_KA/Plot/03_Ghost/scene_conclusion_false|scene_conclusion_false]].

## Preconditions
- Any valid ghost conclusion is reached.
- `sandbox_ghost` can transition from `started` to `completed`.

## Designer View
- Debrief: estate mystery is resolved and outcomes are recorded.

## Mechanics View
- Reward grant: +80 XP and occult training unlock.
- Case status update: ghost branch marked complete.
- Agency follow-up unlock: guildmaster meeting.

## State Delta
- `set_quest_state('sandbox_ghost', 'completed')`
- `ghost_resolved = true`
- `guildmaster_unlocked = true`

## Transitions
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]].

## Validation
- Hub lock condition should activate for estate hub.
- Agency guildmaster transition should become visible.
