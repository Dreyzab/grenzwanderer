---
id: scene_bank_intro
type: vn_scene
phase: sandbox_banker
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_banker
  - phase/investigation
  - location/bank
---

# 🏦 Bank Intro

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_bank_intro_bg]] |
| 🔍 Passive Checks | [[scene_bank_intro_checks]] |
| 📖 Beat 1 | [[scene_bank_intro_beat1]] |
| 📖 Beat 2 | [[scene_bank_intro_beat2]] |

## 👥 Characters
- [[char_banker|Herr Wagner]]

## 🔀 Choices (from Beat 2)
1. [[scene_bank_intro_ch1]] → Accept Case (Unlock Son's House)
2. [[scene_bank_intro_ch2]] → Question Motives (Optional dialogue)

## → Next
[[scene_bank_leads]]
