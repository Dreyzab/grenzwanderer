---
id: scene_bank_intro_beat1
parent: scene_bank_intro
type: vn_beat
order: 1
tags:
  - type/vn_beat
  - case/sandbox_banker
  - location/bank
---

# 📖 Beat 1: Wagner's distress

## VN Script

**[Narrator]**:
"The marble floor of the Badische Landesbank reflects the sunlight like a mirror. 
But the mood is somber. Behind a massive oak desk sits [[char_banker|Herr Wagner]], 
his face pale, hands trembling slightly as he shuffles papers."

**[Herr Wagner]**:
"Ah, you must be the investigator Clara mentioned. Thank you for coming so quickly.
It's about my son, Friedrich. He... disappears every night. And recently, money has started 
vanishing from my private safe."

**[Herr Wagner]**:
"I cannot involve the police. Imagine the scandal! But I fear he has fallen into 
[[ev_bad_company|bad company]]. Please, find out where he goes."

## Evidence Inline
| Word/Phrase | Evidence | Category |
|-------------|----------|----------|
| bad company | [[ev_bad_company]] | Testimony |

## → Next
[[scene_bank_intro_beat2]]
