---
id: scene_bank_leads
type: vn_scene
phase: sandbox_banker
tags:
  - type/hub
  - mechanic/investigation
---

# 🔍 Finding Friedrich

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_map_city_bg]] |
| 📖 Beat 1 | [[scene_bank_leads_dialogue]] |

## 🔀 Investigation Choices

### 🏠 The Richter Villa (Intel?)
- *Condition*: `banker_lead_house_checked` IS FALSE
- *Link*: [[scene_son_house]]
- *Hint*: "His room might have clues about his habits."

### 🍺 The Tavern (Rumors?)
- *Condition*: `banker_lead_tavern_checked` IS FALSE
- *Link*: [[scene_tavern]]
- *Hint*: "He plays cards there regularly."

### 🎰 The Casino (Confrontation)
- *Condition*: `banker_lead_house_checked` OR `banker_lead_tavern_checked` (At least one lead checked)
- *Link*: [[scene_casino_duel]]
- *Hint*: "Face him directly."

## 💡 Tactical Note
"Gathering intel might reveal his weaknesses."

## → Fallback
[[scene_casino_duel]]
