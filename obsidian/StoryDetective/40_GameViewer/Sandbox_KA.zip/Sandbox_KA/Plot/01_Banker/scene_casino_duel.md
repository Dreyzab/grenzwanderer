﻿---
id: scene_casino_duel
type: vn_scene
phase: sandbox_banker
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_banker
  - phase/resolution
  - location/casino
---

# ðŸŽ° Casino Duel

## ðŸ“‹ Structure
| Element | Node |
|---------|------|
| ðŸŽ¨ Background | [[scene_casino_duel_bg]] |
| ðŸ” Passive Checks | [[scene_casino_duel_checks]] |
| ðŸ“– Beat 1 | [[scene_casino_duel_beat1]] |
| âš”ï¸ Battle | [[sandbox_son_duel]] |
| ðŸ“– Beat 2 | [[scene_casino_duel_beat2]] |

## ðŸ‘¥ Characters
- [[char_friedrich|Friedrich Richter]]

## â†’ Exit
[[40_GameViewer/Sandbox_KA/03_Map_Return/scene_banker_exit_to_map|scene_banker_exit_to_map]]

