---
id: scene_casino_duel_beat1
parent: scene_casino_duel
type: vn_beat
order: 1
tags:
  - type/vn_beat
  - mechanic/boss_fight
---

# 📖 Beat 1: The High Stakes Table

## VN Script

**[Friedrich]**: "Another challenger? Or did my father send you?" -> **Arrogant**
**[Detective]**: "The game is over, Friedrich. Come home."
**[Friedrich]**: "beat me, and I might consider it."

*He shuffles the deck aggressively.*

## ⚔️ Tactical Options
1.  **Use Diary Intel**: "I know you bluff on Queens, Friedrich." -> *Lowers Difficulty*
    *   *Condition*: `has_item_diary`
2.  **Use Lucky Coin**: *Grants Reroll Ability*
    *   *Condition*: `has_item_lucky_coin`

## 🎲 The Duel (Card Minigame)
- **Base Difficulty**: 15 (Hard)
- **With Diary**: 10 (Medium)
- **With Coin**: 15 (Hard) + 1 Reroll

*... The cards fly across the table ...*

## → Outcome
[[scene_bank_conclusion]] (Success) OR [[scene_bank_retry]] (Fail)
