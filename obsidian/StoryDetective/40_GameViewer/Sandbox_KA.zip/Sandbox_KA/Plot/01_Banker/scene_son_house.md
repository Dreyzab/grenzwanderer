---
id: scene_son_house
type: vn_scene
phase: sandbox_banker
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_banker
  - phase/investigation
  - location/son_house
---

# 🏠 Son's Apartment

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_son_house_bg]] |
| 🔍 Passive Checks | [[scene_son_house_checks]] |
| 📖 Beat 1 | [[scene_son_house_beat1]] |

## 👥 Characters
- None (Investigation)

## 🔀 Choices
1. [[scene_son_house_ch1]] → Search Desk (Find debt note)
2. [[scene_son_house_ch2]] → Check Wardrobe (Find fancy clothes)

## → Exit
[[map_ka_son_house]]
