---
id: scene_son_house_beat1
parent: scene_son_house
type: vn_beat
order: 1
tags:
  - type/vn_beat
  - mechanic/reward
---

# 📖 Beat 1: The Boy's Room

## VN Script

**[Maid]**: "Herr Friedrich left in a hurry. He took the silver candlesticks!" -> **Panic**
**[Detective]**: "Let me see his room."

*You search the messy bedroom.*

**[Narrator]**: Under the mattress, you find a leather-bound journal. It's full of gambling notes.
> "I always bluff when I hold a Queen. They never suspect it."

**[System]**: You found **Friedrich's Diary**!
*Effect: Unlocks 'Read Bluff' in the Duel.*

## ⚙️ State Delta
- `banker_lead_house_checked = true`
- `has_item_diary = true`

## → Next
[[scene_bank_leads]]
