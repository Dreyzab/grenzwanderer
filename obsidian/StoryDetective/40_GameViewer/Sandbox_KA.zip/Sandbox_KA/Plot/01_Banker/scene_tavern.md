---
id: scene_tavern
type: vn_scene
phase: sandbox_banker
status: active
tags:
  - type/vn_scene
  - layer/vn
  - case/sandbox_banker
  - phase/investigation
  - location/tavern
---

# 🍺 Tavern Intel

## 📋 Structure
| Element | Node |
|---------|------|
| 🎨 Background | [[scene_tavern_bg]] |
| 🔍 Passive Checks | [[scene_tavern_checks]] |
| 📖 Beat 1 | [[scene_tavern_beat1]] |

## 👥 Characters
- [[char_bartender|Bartender Hans]]

## 🔀 Choices
1. [[scene_tavern_ch1]] → Bribe for Info (Easy)
2. [[scene_tavern_ch2]] → Intimidate (Hard Check)

## → Exit
[[map_ka_tavern]]
