---
id: scene_tavern_beat1
parent: scene_tavern
type: vn_beat
order: 1
tags:
  - type/vn_beat
  - mechanic/reward
---

# 📖 Beat 1: The Gambler's Den

## VN Script

**[Barkeeper]**: "Friedrich? He owes everyone money. Even Old Hans over there." -> **Gossip**
**[Old Hans]**: "Richter? He thinks he's clever. But I took his lucky coin last night."

*You challenge Hans to a quick game of dice.* -> **Success** (Logic/Luck Check)

**[Old Hans]**: "Fine, take it. It's cursed anyway."

**[System]**: You obtained **Lucky Coin**!
*Effect: Allows one Reroll in the Duel.*

## ⚙️ State Delta
- `banker_lead_tavern_checked = true`
- `has_item_lucky_coin = true`

## → Next
[[scene_bank_leads]]
