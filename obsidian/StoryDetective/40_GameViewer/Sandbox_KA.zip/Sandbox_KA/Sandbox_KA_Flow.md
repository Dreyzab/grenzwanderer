﻿---
id: sandbox_ka_flow
aliases:
  - Karlsruhe Sandbox Flow
tags:
  - type/moc
  - perspective/gameviewer
  - city/karlsruhe
  - pack/ka1905
  - status/wip
---
# Karlsruhe Sandbox Flow

## Architecture
`scene_start -> scene_language_select -> scene_backstory_select -> scene_map_intro -> map_karlsruhe_main -> hub_* -> scene_*_entry -> Plot/* -> scene_*_exit_to_map -> map_karlsruhe_main`

## Entry Layer
- [[40_GameViewer/Sandbox_KA/00_Entry/scene_start|scene_start]]
- [[40_GameViewer/Sandbox_KA/00_Entry/scene_language_select|scene_language_select]]
- [[40_GameViewer/Sandbox_KA/00_Entry/scene_backstory_select|scene_backstory_select]]
- [[40_GameViewer/Sandbox_KA/00_Entry/scene_map_intro|scene_map_intro]]

## Map Layer
- [[40_GameViewer/Sandbox_KA/00_Global/map_karlsruhe_main|map_karlsruhe_main]]
- [[40_GameViewer/Sandbox_KA/00_Global/char_partner|char_partner]]

Partner guidance requirement:
- "Need to talk with 3 clients." (Bank, Rathaus, Estate)

## Hub Layer
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_bank|hub_bank]] -> [[40_GameViewer/Sandbox_KA/02_Quest_Entries/scene_banker_entry|scene_banker_entry]]
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_rathaus|hub_rathaus]] -> [[40_GameViewer/Sandbox_KA/02_Quest_Entries/scene_dog_entry|scene_dog_entry]]
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_estate|hub_estate]] -> [[40_GameViewer/Sandbox_KA/02_Quest_Entries/scene_ghost_entry|scene_ghost_entry]]
- [[40_GameViewer/Sandbox_KA/01_Hubs/hub_agency|hub_agency]] -> [[40_GameViewer/Sandbox_KA/01_Hubs/scene_agency_guildmaster|scene_agency_guildmaster]] (conditional)

## Quest Wrapper Layer
| Quest | Entry Wrapper | Existing Plot | Exit Wrapper |
|---|---|---|---|
| Banker | `scene_banker_entry` | `Plot/01_Banker/*` | `scene_banker_exit_to_map` |
| Dog | `scene_dog_entry` | `Plot/02_Dog/*` | `scene_dog_exit_to_map` |
| Ghost | `scene_ghost_entry` | `Plot/03_Ghost/*` | `scene_ghost_exit_to_map` |

## Canvas
- Main board: [[40_GameViewer/Sandbox_KA/Sandbox_KA_Flow.canvas|Sandbox_KA_Flow.canvas]]
- Edge labels use `available`, `locked`, `completed` semantics.

## Notes
- Existing plot chains stay in `Plot/**` and are referenced by wrappers.
- Exit wrappers are the only approved return path to the main map in this flow.
